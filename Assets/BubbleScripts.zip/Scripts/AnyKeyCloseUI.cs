using UnityEngine;

public class AnyKeyCloseUI : MonoBehaviour
{
    [Header("Ҫ�رյ� UI ���ڵ�")]
    public GameObject targetUI;

    [Header("�Ƿ��ڹرպ����ٸö���")]
    public bool destroyAfterClose = false;

    private bool isClosed = false;

    void Update()
    {
        if (isClosed) return;

        // �������������������
        if (Input.anyKeyDown || Input.GetMouseButtonDown(0) || Input.touchCount > 0)
        {
            CloseUI();
        }
    }

    private void CloseUI()
    {
        if (!targetUI) targetUI = gameObject;

        if (destroyAfterClose)
        {
            Destroy(targetUI);
        }
        else
        {
            targetUI.SetActive(false);
        }

        isClosed = true;
    }
}